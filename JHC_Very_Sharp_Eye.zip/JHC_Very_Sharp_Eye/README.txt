See LICENSE.txt for rules on copying and redistributing.

This is a very bare-bones script to complete the Very Sharp Eye achievement in the game
"Purple Place".

Because of the exceedingly low chances of completing the achievement in a short amount of time,
this was made to automate the process so you can leave it running and go do more productive things.

To use, simply open the game on the right most monitor, then open the .exe file. pressing F6 will stop the script at any time, and pressing F7 will restart it.

If Windows gives a unknown author popup, simply press "Learn More", then "Run Anyway". The full raw .py file is available to look at in the github repo.

The time to complete the achievement varies widely, but generally takes between 2-10 hours, but can take longer.

I hope this helps! -JHCode